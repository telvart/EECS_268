/**
*	@file: MazeWalker.cpp
*	@author: Tim Elvart
*	KUID: 2760606
*	Email: telvart@ku.edu
*	@date:11/11/15
*	@brief:Implementation of methods declared in MazeWalker.h
*/

#include "MazeWalker.h"


MazeWalker::MazeWalker(const char* const* mazePtr, int startRow, int startCol, int rows, int cols, Search searchChoice)
	:m_curPos(startRow,startCol), m_startPos(startRow,startCol)
{
}

MazeWalker::~MazeWalker()
{
}

/*bool MazeWalker::walkMaze()
{
}

const int* const* MazeWalker::getVisited() const
{
}

int MazeWalker::getVisitedRows() const
{
}

int MazeWalker::getVisitedCols() const
{
}


const char* const* MazeWalker::getMaze() const
{
}


void MazeWalker::storeValidMoves()
{
}


void MazeWalker::move(Position& p)
{
}

		
bool MazeWalker::isGoalReached() const
{
}


*/






