/**
*	@file: main.cpp
*	@author: Tim Elvart
*	KUID: 2760606
*	Email: telvart@ku.edu
*	@date:11/11/15
*	@brief: A place to interact with maze files and their traversal
*/


#include <iostream>
#include "MazeWalker.h"
#include "MazeReader.h"

/*void print2DCharArray(const char* const* char** array, int rows, int cols)
{
	for (int i=0; i<rows; i++)
	{
		for (int j=0; j<cols; j++)
		{
			std::cout<<array[i][j];
		}
	}
}
*/
int main()
{
	try
	{
		MazeReader reader=MazeReader("maze.txt");
	}
	catch(...)
	{
		std::cout<<"\nException thrown";
	}	
//print2DCharArray(reader.getMaze(),reader.getRows(),reader.getCols());

}
